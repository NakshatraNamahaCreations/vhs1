const sendtemplatecontroller=require("../controller/sendtemplate");
